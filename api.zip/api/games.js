module.exports = async (req, res) => {
  const apiBase = String(process.env.RENDER_API_URL || '').replace(/\/$/, '');
  if (!apiBase) return res.status(503).json({ error: 'Render API is not configured' });
  try {
    const target = new URL('/api/games', apiBase);
    for (const [key, value] of Object.entries(req.query || {})) target.searchParams.set(key, String(value));
    const upstream = await fetch(target, { headers: { Accept: 'application/json' } });
    const payload = await upstream.json();
    res.setHeader('Cache-Control', 'no-store');
    return res.status(upstream.status).json(payload);
  } catch {
    return res.status(503).json({ error: 'Render API is unavailable' });
  }
};
