module.exports = require('../data/games.json');
