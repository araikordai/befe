const path = require('node:path');
const express = require('express');
const cors = require('cors');
const { createClient } = require('@supabase/supabase-js');

const app = express();
const port = Number(process.env.PORT || 10000);
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseAnonKey = process.env.SUPABASE_ANON_KEY;
const allowedOrigins = (process.env.FRONTEND_ORIGIN || '').split(',').map(x => x.trim()).filter(Boolean);
const renderOrigin = process.env.RENDER_EXTERNAL_URL || '';

app.use(cors({
  origin(origin, callback) {
    if (!origin || allowedOrigins.length === 0 || allowedOrigins.includes(origin) || origin === renderOrigin) return callback(null, true);
    return callback(new Error('Origin is not allowed by CORS'));
  },
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json({ limit: '32kb' }));
app.use(express.static(path.join(__dirname, '..', 'frontend')));

function getClient(token) {
  if (!supabaseUrl || !supabaseAnonKey) throw new Error('Supabase is not configured');
  return createClient(supabaseUrl, supabaseAnonKey, {
    auth: { persistSession: false, autoRefreshToken: false },
    ...(token ? { global: { headers: { Authorization: `Bearer ${token}` } } } : {})
  });
}

function getBearer(req) {
  const value = req.get('authorization') || '';
  return value.startsWith('Bearer ') ? value.slice(7) : '';
}

async function requireUser(req, res, next) {
  try {
    const token = getBearer(req);
    if (!token) return res.status(401).json({ error: 'ต้องเข้าสู่ระบบก่อน' });
    const client = getClient(token);
    const { data, error } = await client.auth.getUser(token);
    if (error || !data.user) return res.status(401).json({ error: 'เซสชันหมดอายุ กรุณาเข้าสู่ระบบใหม่' });
    req.user = data.user;
    req.supabase = client;
    next();
  } catch (error) {
    next(error);
  }
}

function handleDbError(res, error) {
  console.error(error.message);
  return res.status(500).json({ error: 'ไม่สามารถอ่านหรือบันทึกข้อมูลได้ในขณะนี้' });
}

app.get('/api/health', (_req, res) => res.json({ status: 'ok' }));

app.get('/api/config', (_req, res) => {
  if (!supabaseUrl || !supabaseAnonKey) return res.status(503).json({ error: 'Supabase is not configured' });
  res.setHeader('Cache-Control', 'no-store');
  res.json({ apiBase: process.env.PUBLIC_API_URL || '', supabaseUrl, supabaseAnonKey });
});

app.get('/api/games', async (req, res) => {
  try {
    const client = getClient();
    const [{ data: games, error: gamesError }, { data: stats, error: statsError }] = await Promise.all([
      client.from('games').select('id,title,genre,platform,year,image,description').order('id'),
      client.from('game_rating_summary').select('game_id,average_rating,vote_count')
    ]);
    if (gamesError) return handleDbError(res, gamesError);
    if (statsError) return handleDbError(res, statsError);
    const summary = new Map((stats || []).map(row => [row.game_id, row]));
    const q = String(req.query.q || '').trim().toLowerCase();
    const genre = String(req.query.genre || '').trim().toLowerCase();
    const results = (games || []).filter(game => {
      const matchesText = !q || `${game.title} ${game.genre} ${game.description}`.toLowerCase().includes(q);
      const matchesGenre = !genre || genre === 'ทั้งหมด' || game.genre.toLowerCase().includes(genre);
      return matchesText && matchesGenre;
    }).map(game => {
      const rating = summary.get(game.id);
      return { ...game, average_rating: rating ? Number(rating.average_rating) : null, vote_count: rating ? Number(rating.vote_count) : 0 };
    });
    res.setHeader('Cache-Control', 'no-store');
    res.json({ games: results, total: results.length });
  } catch (error) {
    handleDbError(res, error);
  }
});

app.get('/api/reviews', async (req, res) => {
  try {
    const limit = Math.min(10, Math.max(1, Number(req.query.limit) || 2));
    const { data, count, error } = await getClient().from('review_feed').select('id,game_id,game_title,body,author_name,score,created_at', { count: 'exact' }).order('created_at', { ascending: false }).limit(limit);
    if (error) return handleDbError(res, error);
    res.json({ reviews: data || [], total: count || 0 });
  } catch (error) {
    handleDbError(res, error);
  }
});

app.get('/api/games/:id/ratings', async (req, res) => {
  try {
    const gameId = Number(req.params.id);
    const client = getClient();
    const [{ data: stats, error: statsError }, userRating] = await Promise.all([
      client.from('game_rating_summary').select('average_rating,vote_count').eq('game_id', gameId).maybeSingle(),
      (async () => {
        const token = getBearer(req);
        if (!token) return { data: null, error: null };
        const userClient = getClient(token);
        const { data: user, error: authError } = await userClient.auth.getUser(token);
        if (authError || !user.user) return { data: null, error: null };
        return userClient.from('ratings').select('score').eq('game_id', gameId).maybeSingle();
      })()
    ]);
    if (statsError) return handleDbError(res, statsError);
    if (userRating.error) return handleDbError(res, userRating.error);
    res.setHeader('Cache-Control', 'no-store');
    res.json({ average_rating: stats ? Number(stats.average_rating) : null, vote_count: stats ? Number(stats.vote_count) : 0, user_rating: userRating.data?.score ?? null });
  } catch (error) {
    handleDbError(res, error);
  }
});

app.put('/api/games/:id/ratings', requireUser, async (req, res) => {
  const gameId = Number(req.params.id);
  const score = Number(req.body?.score);
  if (!Number.isInteger(gameId) || !Number.isInteger(score) || score < 1 || score > 10) return res.status(400).json({ error: 'คะแนนต้องเป็นจำนวนเต็มระหว่าง 1 ถึง 10' });
  try {
    const { error } = await req.supabase.from('ratings').upsert({ game_id: gameId, user_id: req.user.id, score, updated_at: new Date().toISOString() }, { onConflict: 'game_id,user_id' });
    if (error) return handleDbError(res, error);
    const { data: stats, error: statsError } = await req.supabase.from('game_rating_summary').select('average_rating,vote_count').eq('game_id', gameId).single();
    if (statsError) return handleDbError(res, statsError);
    res.json({ average_rating: Number(stats.average_rating), vote_count: Number(stats.vote_count), user_rating: score });
  } catch (error) {
    handleDbError(res, error);
  }
});

app.get('/api/games/:id/reviews', async (req, res) => {
  try {
    const { data, error } = await getClient().from('review_feed').select('id,game_id,game_title,body,author_name,score,created_at').eq('game_id', Number(req.params.id)).order('created_at', { ascending: false }).limit(50);
    if (error) return handleDbError(res, error);
    res.json({ reviews: data || [] });
  } catch (error) {
    handleDbError(res, error);
  }
});

app.post('/api/games/:id/reviews', requireUser, async (req, res) => {
  const gameId = Number(req.params.id);
  const body = String(req.body?.body || '').trim();
  if (!Number.isInteger(gameId) || body.length < 2 || body.length > 1000) return res.status(400).json({ error: 'รีวิวต้องมีความยาว 2–1,000 ตัวอักษร' });
  const authorName = String(req.user.user_metadata?.display_name || req.user.email?.split('@')[0] || 'ผู้เล่น').slice(0, 32);
  try {
    const { data, error } = await req.supabase.from('reviews').insert({ game_id: gameId, user_id: req.user.id, author_name: authorName, body }).select('id,game_id,body,author_name,created_at').single();
    if (error) return handleDbError(res, error);
    res.status(201).json({ review: data });
  } catch (error) {
    handleDbError(res, error);
  }
});

app.get('/api/me/favorites', requireUser, async (req, res) => {
  const { data, error } = await req.supabase.from('favorites').select('game_id').eq('user_id', req.user.id);
  if (error) return handleDbError(res, error);
  res.json({ favorites: (data || []).map(row => row.game_id) });
});

app.put('/api/me/favorites/:id', requireUser, async (req, res) => {
  const gameId = Number(req.params.id);
  if (!Number.isInteger(gameId)) return res.status(400).json({ error: 'รหัสเกมไม่ถูกต้อง' });
  const { error } = await req.supabase.from('favorites').upsert({ game_id: gameId, user_id: req.user.id }, { onConflict: 'game_id,user_id', ignoreDuplicates: true });
  if (error) return handleDbError(res, error);
  res.json({ favorite: true, game_id: gameId });
});

app.delete('/api/me/favorites/:id', requireUser, async (req, res) => {
  const gameId = Number(req.params.id);
  const { error } = await req.supabase.from('favorites').delete().eq('game_id', gameId).eq('user_id', req.user.id);
  if (error) return handleDbError(res, error);
  res.json({ favorite: false, game_id: gameId });
});

app.get('*', (_req, res) => res.sendFile(path.join(__dirname, '..', 'frontend', 'index.html')));

app.use((error, _req, res, _next) => {
  console.error(error.message);
  res.status(500).json({ error: 'เซิร์ฟเวอร์มีปัญหา กรุณาลองใหม่' });
});

app.listen(port, '0.0.0.0', () => console.log(`PLAYLOG API listening on 0.0.0.0:${port}`));
