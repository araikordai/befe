-- PLAYLOG ratings, reviews, favorites, and public game catalog.
create table if not exists public.games (
  id bigint primary key,
  title text not null,
  genre text not null,
  platform text not null,
  year integer not null,
  image text not null,
  description text not null
);

-- Catalog metadata only. Scores and vote counts are intentionally not seeded.
insert into public.games (id,title,genre,platform,year,image,description) values
(1,'Hollow Knight: Silksong','แอ็กชัน / ผจญภัย','PC · Switch · PlayStation',2025,'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=900&q=85','ออกเดินทางไปกับ Hornet สู่ดินแดนใหม่ที่เต็มไปด้วยอาณาจักรโบราณ ศัตรูแปลกตา และความลับที่รอการค้นพบ'),
(2,'Clair Obscur: Expedition 33','RPG / ผจญภัย','PC · PlayStation · Xbox',2025,'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=900&q=85','ผจญภัยในโลกแฟนตาซีที่ได้แรงบันดาลใจจากฝรั่งเศส ออกเดินทางเพื่อหยุดยั้ง Paintress ก่อนเธอจะลบล้างทุกชีวิต'),
(3,'Elden Ring: Shadow of the Erdtree','แอ็กชัน RPG','PC · PlayStation · Xbox',2024,'https://images.unsplash.com/photo-1518709594023-6eab9bab7b23?auto=format&fit=crop&w=900&q=85','ก้าวเข้าสู่ดินแดนเงา สำรวจโลกใหม่ที่เชื่อมโยงกัน และเผชิญหน้ากับบอสสุดท้าทายในภาคเสริมของ Elden Ring'),
(4,'Baldur''s Gate 3','RPG / วางแผน','PC · PlayStation · Xbox',2023,'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=900&q=85','รวบรวมปาร์ตี้ ตัดสินใจทุกทางแยก และสร้างเรื่องราวของคุณเองในโลก Dungeons & Dragons ที่ตอบสนองทุกการเลือก'),
(5,'Stardew Valley','จำลองชีวิต / ทำฟาร์ม','PC · Switch · Mobile',2016,'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?auto=format&fit=crop&w=900&q=85','เริ่มต้นชีวิตใหม่ในฟาร์มเก่า ปลูกพืช เลี้ยงสัตว์ สร้างมิตรภาพ และค้นพบเรื่องราวเล็ก ๆ ในเมือง Pelican Town'),
(6,'Hades II','แอ็กชัน / Roguelike','PC · Switch',2025,'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=900&q=85','สวมบท Melinoë เจ้าหญิงแห่งยมโลก ใช้เวทมนตร์และพลังจากเทพโอลิมปัสต่อสู้กับไททันแห่งกาลเวลา')
on conflict (id) do update set title=excluded.title,genre=excluded.genre,platform=excluded.platform,year=excluded.year,image=excluded.image,description=excluded.description;

create table if not exists public.ratings (
  game_id bigint not null references public.games(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  score smallint not null check (score between 1 and 10),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (game_id,user_id)
);

create table if not exists public.reviews (
  id bigint generated always as identity primary key,
  game_id bigint not null references public.games(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  author_name text not null check (char_length(author_name) between 1 and 32),
  body text not null check (char_length(body) between 2 and 1000),
  created_at timestamptz not null default now()
);
create index if not exists reviews_game_created_idx on public.reviews (game_id,created_at desc);

create table if not exists public.favorites (
  game_id bigint not null references public.games(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (game_id,user_id)
);

alter table public.games enable row level security;
alter table public.ratings enable row level security;
alter table public.reviews enable row level security;
alter table public.favorites enable row level security;

revoke all on public.games,public.ratings,public.reviews,public.favorites from anon,authenticated;
grant select on public.games to anon,authenticated;
grant select,insert,update,delete on public.ratings to authenticated;
grant select on public.reviews to authenticated;
grant insert,update,delete on public.reviews to authenticated;
grant select,insert,delete on public.favorites to authenticated;
grant usage,select on sequence public.reviews_id_seq to authenticated;

 drop policy if exists "Anyone can read the game catalog" on public.games;
create policy "Anyone can read the game catalog" on public.games for select to anon,authenticated using (true);

drop policy if exists "Signed in users can read ratings" on public.ratings;
create policy "Signed in users can read ratings" on public.ratings for select to authenticated using ((select auth.uid()) is not null and (select auth.uid())=user_id);
drop policy if exists "Users can add their own rating" on public.ratings;
create policy "Users can add their own rating" on public.ratings for insert to authenticated with check ((select auth.uid())=user_id);
drop policy if exists "Users can change their own rating" on public.ratings;
create policy "Users can change their own rating" on public.ratings for update to authenticated using ((select auth.uid())=user_id) with check ((select auth.uid())=user_id);
drop policy if exists "Users can remove their own rating" on public.ratings;
create policy "Users can remove their own rating" on public.ratings for delete to authenticated using ((select auth.uid())=user_id);

drop policy if exists "Anyone can read reviews" on public.reviews;
drop policy if exists "Users can read their own reviews" on public.reviews;
create policy "Users can read their own reviews" on public.reviews for select to authenticated using ((select auth.uid())=user_id);
drop policy if exists "Users can publish their own reviews" on public.reviews;
create policy "Users can publish their own reviews" on public.reviews for insert to authenticated with check ((select auth.uid())=user_id);
drop policy if exists "Users can edit their own reviews" on public.reviews;
create policy "Users can edit their own reviews" on public.reviews for update to authenticated using ((select auth.uid())=user_id) with check ((select auth.uid())=user_id);
drop policy if exists "Users can delete their own reviews" on public.reviews;
create policy "Users can delete their own reviews" on public.reviews for delete to authenticated using ((select auth.uid())=user_id);

 drop policy if exists "Users can read their own favorites" on public.favorites;
create policy "Users can read their own favorites" on public.favorites for select to authenticated using ((select auth.uid())=user_id);
drop policy if exists "Users can add their own favorites" on public.favorites;
create policy "Users can add their own favorites" on public.favorites for insert to authenticated with check ((select auth.uid())=user_id);
drop policy if exists "Users can remove their own favorites" on public.favorites;
create policy "Users can remove their own favorites" on public.favorites for delete to authenticated using ((select auth.uid())=user_id);

-- Public aggregate exposes only average and vote count, never user IDs or individual ratings.
create or replace view public.game_rating_summary as
  select game_id,
         round(avg(score)::numeric,1) as average_rating,
         count(*)::integer as vote_count
  from public.ratings
  group by game_id;
revoke all on public.game_rating_summary from anon,authenticated;
grant select on public.game_rating_summary to anon,authenticated;

-- Public review feed exposes display names and review scores without exposing user IDs.
create or replace view public.review_feed as
  select r.id,r.game_id,g.title as game_title,r.body,r.author_name,r.created_at,rt.score
  from public.reviews as r
  join public.games as g on g.id=r.game_id
  left join public.ratings as rt on rt.game_id=r.game_id and rt.user_id=r.user_id;
revoke all on public.review_feed from anon,authenticated;
grant select on public.review_feed to anon,authenticated;
